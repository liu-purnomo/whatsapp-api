# WhatsApp API

This is a simple REST API for WhatsApp. It is built using Node.js Express

## Installation

Clone the repository

```bash
git clone https://github.com/liupurnomo/whatsapp-api.git
```
Enter the folder

```bash
cd whatsapp-api
```
Install the dependencies

```bash
npm install
```
Then open browser and go to `http://localhost:3000`